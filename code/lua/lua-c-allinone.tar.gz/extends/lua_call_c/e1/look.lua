package.cpath = "./?.so;./?.dll" -- 指定lua搜索c library的path
require "stacklook"

print("stack.look", stack.look(1, 2, 3, 4, 5, 6, 7))

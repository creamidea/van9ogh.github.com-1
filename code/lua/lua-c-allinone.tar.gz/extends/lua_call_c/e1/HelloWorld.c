#define LUA_COMPAT_MODULE
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <stdio.h>

static int _SayHelloWorld(lua_State *L)
{

	int i, nArgs = lua_gettop(L);

	for (i = 1; i <= nArgs; i++) printf("%s ", lua_tostring(L, i));
	printf("Hello World!\n");

	lua_pushstring(L, "2013");
	lua_pushstring(L, "0101");

	return 2;
}

int luaopen_sayhello(lua_State *L)
{
/*	static const luaL_Reg Map[] = {
		{"sayhello", _SayHelloWorld},
		{NULL , NULL}
	};

	luaL_register(L, "sayhello", Map);
*/
	lua_register(L, "sayhello", _SayHelloWorld);
	return 1;
}

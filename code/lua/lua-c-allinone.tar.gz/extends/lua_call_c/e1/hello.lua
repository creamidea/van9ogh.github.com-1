require("sayhello")

time1, time2 = sayhello("LiuPeng")
print(time1, time2)

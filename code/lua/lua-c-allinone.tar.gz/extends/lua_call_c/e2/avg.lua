-- Call c C function

avg, sum = average(10, 20, 30, 40, 50)
print("The avergae is ", avg)
print("The sum is ", sum)

avg, sum = average(1, 2, 3, 4, 5)
print("The avergae is ", avg)
print("The sum is ", sum)

print("Hello Liu Peng!")

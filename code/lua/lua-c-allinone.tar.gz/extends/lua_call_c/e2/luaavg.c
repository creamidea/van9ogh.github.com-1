/* 这个demo有点像综合应用, 因为在C中我们调用了
   lua脚本, 而在lua中我们又使用了C中的average
*/

#include <stdio.h>
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"

lua_State *L;

static int average(lua_State *L)
{
	int n = lua_gettop(L);
	double sum = 0;
	int i;

	for (i = 1; i <= n; i++) sum += lua_tonumber(L, i);
	lua_pushnumber(L, sum / n);
	lua_pushnumber(L, sum);

	return 2;
}

int main(int argc, char *argv[])
{
//	L = lua_open();
	L = luaL_newstate();
	luaL_openlibs(L);
	lua_register(L, "average", average);
	luaL_dofile(L, "./avg.lua");
	lua_close(L);
	printf("Press enter to exit...");
	getchar();
	return 0;
}

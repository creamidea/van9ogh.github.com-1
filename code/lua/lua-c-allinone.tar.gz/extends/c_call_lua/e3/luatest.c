#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#ifdef __cplusplus
}
#endif

int main(void)
{
	int s = 0;
	lua_State *L = luaL_newstate();

	luaL_openlibs(L);

	luaL_dofile(L, "foo.lua");

	printf("\nAllright we are back in C.\n");

	lua_close(L);

	return 0;
}

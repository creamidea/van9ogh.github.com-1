io.write("Please enter your name: ");
name = io.read() -- read input from user
print("Hi " .. name .. ", did you know we are in lua right now?")

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

// 这种就是直接调用, 没有用到间接的函数包装

int main(void)
{
	double z;

	lua_State *L = luaL_newstate();

	/* 载入lua标准库 */
	luaL_openlibs(L);

	/* 正常情况下, lua_pcall和lua_call一样, 不同的
	   是最后一个参数.其中第二个0表示返回值个数为0
	   这句话是说:
	     1. 正确情况下luaL_loadfile返回0, 并且执行lua_pcall
	     2. 错误情况下, 直接运行{}块中Code
	*/
	if (luaL_loadfile(L, "last.lua") || lua_pcall(L, 0, 0, 0)) {
	
		/* 错误会被压入栈顶, 不过需要将它转化为字符串 */
		printf("error: %s", lua_tostring(L, -1));
		return -1;
	}

	/* 将f函数入栈 */
	lua_getglobal(L, "f");

	/* 检查入栈的是否为函数 */
	if (!lua_isfunction(L, -1)) {
		lua_pop(L, -1);
		return -1;
	}

	/* 传入两个参数21, 31 */
	lua_pushnumber(L, 21);
	lua_pushnumber(L, 31);

	/* 执行函数, 2表示有两个参数, 1表示有一个返回值, 0表示没有错误
	   表现就是lua_call */
	if (lua_pcall(L, 2, 1, 0) != 0) {
		printf("error running function `f': %s\n", lua_tostring(L, -1));
		return -1;
	}

	/* 检查返回值是不是一个数字, 一旦lua_pcall运行完毕, 函数和另外的参数
	   就被自动的弹出了栈, 因此栈中的内容将是返回值 */
	if (!lua_isnumber(L, -1)) {
		printf("function `f' must return a number\n");
		return -1;
	}

	/* 将栈顶中的内容转化为double */
	z = lua_tonumber(L, -1);
	printf("Result: %f\n", z);

	/* 弹出栈中一个元素 */
	lua_pop(L, 1);

	/* 释放L */
	lua_close(L);

	return 0;
}

function f(x, y)
	return (x^2 * math.sin(y)) / (1 - x)
end

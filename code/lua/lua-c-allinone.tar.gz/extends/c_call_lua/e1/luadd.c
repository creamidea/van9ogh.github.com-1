#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#ifdef __cplusplus
}
#endif

lua_State *L;

int luaadd(int x, int y)
{
	int sum;
	lua_getglobal(L, "add"); // 先将lua脚本中的add函数压栈
	lua_pushnumber(L, x);    // 再将两个参数压栈
	lua_pushnumber(L, y);
	lua_call(L, 2, 1);       // 调用lua脚本中的add函数, 2表示参数个数, 1表示结果个数
	sum = (int)lua_tointeger(L, -1); // 索引为-x表示栈顶的x位置, 索引为x表示栈底的x位置
	lua_pop(L, 1);           // 弹出1个元素, 1表示弹出的元素个数
	return sum;
}

int main(int argc, char *argv[])
{
	int sum;

	L = luaL_newstate();       // 在lua5.2中不支持lua_open, 因此使用luaL_newstate()
	luaL_openlibs(L);          // 将lua标准库载入L
	luaL_dofile(L, "add.lua"); // 载入并运行lua脚本add.lua
	sum = luaadd(10, 15);      // 运行luaadd函数
	printf("The sum is %d\n", sum);
	lua_close(L);              // 释放L
	return 0;
}

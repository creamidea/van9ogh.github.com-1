require "zstring"

print(zst_strlen("Hello World"))

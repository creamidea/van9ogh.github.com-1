#include <string.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

static int zst_strlen(lua_State *L)
{
	size_t len;
	len = strlen(lua_tostring(L, 1));
	lua_pushnumber(L, len);

	return 1;
}

int luaopen_zstring(lua_State *L)
{
	lua_register(L, "zst_strlen", zst_strlen);
	return 0;
}

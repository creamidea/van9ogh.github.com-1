#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>

/* system */
static int _exec(lua_State *L)
{
        int status;
    status = system(lua_tostring(L, 1));
    lua_pushnumber(L, status);
    return 1;
}

/* mkdir */
static int _mkdir(lua_State *L)
{
        int status;
        mode_t mode = lua_tonumber(L, 2);
        status = mkdir(lua_tostring(L, 1), mode);
        lua_pushnumber(L, status);
        return 1;
}

/* symlink */ 
static int _symlink(lua_State *L)
{
        int status;
        const char *old = lua_tostring(L, 1);
        const char *new = lua_tostring(L, 2);
        status = symlink(old, new);
        lua_pushnumber(L, status);
        return 1;
}

/* rmdir */
static int _rmdir(lua_State *L)
{
        int status;
        status = rmdir(lua_tostring(L, 1));
        lua_pushnumber(L, status);
        return 1;
}

/* rename */
static int _rename(lua_State *L)
{
    int status;
    const char *old = lua_tostring(L, 1);
    const char *new = lua_tostring(L, 2);
    status = rename(old, new);
    lua_pushnumber(L, status);
    return 1;   
}

/* remove */
static int _remove(lua_State *L)
{
        int status;
        const char *filename = lua_tostring(L, 1);
        status = remove(filename);
        lua_pushnumber(L, status);
        return 1;
}

/* chown */
static int _chown(lua_State *L)
{
    int status;
    const char *filename = lua_tostring(L, 1);
    uid_t owner = lua_tonumber(L, 2);
    gid_t group = lua_tonumber(L, 3);
    status = chown(filename, owner, group);
    lua_pushnumber(L, status);
    return 1;   
}

/* chmod */
static int _chmod(lua_State *L)
{
    int status;
    const char *filename = lua_tostring(L, 1);
    mode_t mode = lua_tonumber(L, 2);
    status = chmod(filename, mode);
    lua_pushnumber(L, status);
    return 1;

}

/* get_current_dir_name */
static int _getcwd(lua_State *L)
{
    char *dir;
    dir = (char *)get_current_dir_name();
    lua_pushstring(L, dir);
    return 1;
}

int luaopen_syscall(lua_State *L) 
{
    lua_register(L,"exec",    _exec);
    lua_register(L,"mkdir",   _mkdir);
    lua_register(L,"symlink", _symlink);
    lua_register(L,"rmdir",   _rmdir);
    lua_register(L,"rename",  _rename);
    lua_register(L,"remove",  _remove);
    lua_register(L,"chown",   _chown);
    lua_register(L,"chmod",   _chmod);
    lua_register(L,"getcwd",  _getcwd);

    return 0;
}

require "syscall"

rename("test", "test2")

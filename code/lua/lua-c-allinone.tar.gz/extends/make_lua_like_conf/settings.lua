appName = "Firefox"
screenWidth = 400

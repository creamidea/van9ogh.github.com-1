#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#ifdef __cplusplus
}
#endif

int main(void)
{
	lua_State *L = luaL_newstate();
	if (luaL_loadfile(L, "settings.lua") || lua_pcall(L, 0, 0, 0)) {
		printf("Error failed to load %s", lua_tostring(L, -1));
	} else {
		lua_getglobal(L, "screenWidth");
		const int screenWidth = lua_tonumber(L, -1);
		printf("Screen Width = %d\n", screenWidth);

		lua_getglobal(L, "appName");
		const char *appName = luaL_checkstring(L, -1);
		printf("Screen Name = %s\n", appName);
	}

	lua_close(L);

	printf("Success!\n");

	return 0;
}
